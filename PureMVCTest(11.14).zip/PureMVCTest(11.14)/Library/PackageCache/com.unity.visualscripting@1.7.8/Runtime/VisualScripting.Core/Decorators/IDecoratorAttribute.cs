using System;

namespace Unity.VisualScripting
{
    public interface IDecoratorAttribute
    {
        Type type { get; }
    }
}
