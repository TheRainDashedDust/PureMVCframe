namespace Unity.VisualScripting
{
    [Inspector(typeof(GraphGroup))]
    public class GraphGroupInspector : ReflectedInspector
    {
        public GraphGroupInspector(Metadata metadata) : base(metadata) { }
    }
}
