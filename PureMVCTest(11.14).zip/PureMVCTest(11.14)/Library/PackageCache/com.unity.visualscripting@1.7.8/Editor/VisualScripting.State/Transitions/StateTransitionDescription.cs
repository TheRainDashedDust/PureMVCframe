namespace Unity.VisualScripting
{
    public sealed class StateTransitionDescription : GraphElementDescription
    {
        public string label { get; set; }
        public string tooltip { get; set; }
    }
}
