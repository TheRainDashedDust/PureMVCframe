namespace Unity.VisualScripting
{
    public sealed class StateTransitionAnalysis : GraphElementAnalysis
    {
        public bool isTraversed { get; set; }
    }
}
