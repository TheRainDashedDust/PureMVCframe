namespace Unity.VisualScripting
{
    public static class UnitOptionUtility
    {
        public const string GenerateUnitDatabasePath = "Edit > Project Settings > Visual Scripting > Node Library > Regenerate Nodes";
    }
}
