using UnityEngine;

namespace Unity.VisualScripting
{
    public interface IUnitConnectionWidget : IGraphElementWidget
    {
        Color color { get; }
    }
}
